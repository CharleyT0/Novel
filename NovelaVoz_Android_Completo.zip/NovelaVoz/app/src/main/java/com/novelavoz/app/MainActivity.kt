package com.novelavoz.app

import android.app.Activity
import android.content.*
import android.os.*
import android.graphics.Color
import android.view.View
import android.webkit.*
import android.widget.*
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import kotlin.concurrent.thread

class MainActivity : Activity() {
 private lateinit var web: WebView
 private lateinit var address: EditText
 private lateinit var content: EditText
 private lateinit var status: TextView
 private lateinit var languages: Spinner
 private lateinit var speed: SeekBar
 private lateinit var library: LibraryStore
 private var original = ""
 private var translated = ""
 private var chapterTitle = ""
 private var nextUrl = ""
 private var operation = 0
 private var autoNext = false
 private val handler = Handler(Looper.getMainLooper())
 private val prefs by lazy { getSharedPreferences("novelavoz", MODE_PRIVATE) }
 private val receiver = object : BroadcastReceiver() {
  override fun onReceive(context: Context?, intent: Intent?) {
   status.text = intent?.getStringExtra("state") ?: ""
   if (intent?.getBooleanExtra("completed", false) == true && autoNext) {
    val next = intent.getStringExtra("next_url").orEmpty()
    if (next.startsWith("https://")) { address.setText(next); openUrl(); handler.postDelayed({ extract(true) }, 2300) }
   }
  }
 }
 override fun onCreate(savedInstanceState: Bundle?) {
  super.onCreate(savedInstanceState)
  library = LibraryStore(this)
  val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(14, 12, 14, 8); setBackgroundColor(Color.rgb(247,247,251)) }
  fun button(label: String, action: () -> Unit) = Button(this).apply { text = label; setOnClickListener { action() }; textSize = 12f; isAllCaps = false }
  fun row(vararg items: View) = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; items.forEach { addView(it, LinearLayout.LayoutParams(0, -2, 1f)) } }
  root.addView(TextView(this).apply { text = "NovelaVoz · Novelas en español"; textSize = 21f; setTextColor(Color.BLACK) })
  address = EditText(this).apply { setSingleLine(true); hint = "Enlace HTTPS del capítulo"; setText(prefs.getString("url", "")); inputType = android.text.InputType.TYPE_TEXT_VARIATION_URI }
  root.addView(address)
  root.addView(row(button("Abrir web") { openUrl() }, button("Extraer capítulo") { extract(false) }, button("Siguiente") { openNext() }))
  languages = Spinner(this).apply { adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, listOf("Inglés", "Chino", "Japonés", "Coreano", "Francés", "Portugués", "Alemán", "Español")) }
  root.addView(row(languages, button("Traducir a español") { translate(false) }))
  status = TextView(this).apply { text = "Abre una novela o selecciona un capítulo guardado"; setTextColor(Color.DKGRAY) }
  root.addView(status)
  content = EditText(this).apply { gravity = android.view.Gravity.TOP; hint = "Texto del capítulo"; minLines = 8; setText(prefs.getString("text", "")) }
  root.addView(ScrollView(this).apply { addView(content) }, LinearLayout.LayoutParams(-1, 0, 1f))
  root.addView(row(button("▶ Escuchar") { play() }, button("⏸ Pausar") { player(ReaderService.ACTION_PAUSE) }, button("▶ Seguir") { player(ReaderService.ACTION_PLAY) }, button("■ Parar") { player(ReaderService.ACTION_STOP) }))
  root.addView(TextView(this).apply { text = "Velocidad de voz (0.7×–1.7×)" })
  speed = SeekBar(this).apply { max = 100; progress = prefs.getInt("speed", 30) }
  root.addView(speed)
  val nextCheck = CheckBox(this).apply { text = "Pasar y traducir el siguiente capítulo automáticamente (experimental)"; isChecked = prefs.getBoolean("auto", false); autoNext = isChecked; setOnCheckedChangeListener { _, checked -> autoNext = checked; prefs.edit().putBoolean("auto", checked).apply() } }
  root.addView(nextCheck)
  root.addView(row(button("Guardar capítulo") { saveChapter() }, button("Biblioteca") { showLibrary() }, button("Ver / ocultar web") { web.visibility = if (web.visibility == View.VISIBLE) View.GONE else View.VISIBLE }))
  web = WebView(this).apply {
   settings.javaScriptEnabled = true; settings.domStorageEnabled = true
   settings.allowFileAccess = false; settings.allowContentAccess = false
   webViewClient = object : WebViewClient() {
    override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean = request?.url?.scheme != "https"
    override fun onPageFinished(view: WebView?, url: String?) { address.setText(url); chapterTitle = view?.title.orEmpty(); status.text = "Página cargada. Extrae el capítulo." }
   }
   webChromeClient = WebChromeClient(); visibility = View.GONE
  }
  root.addView(web, LinearLayout.LayoutParams(-1, 0, 1f))
  setContentView(root)
  if (Build.VERSION.SDK_INT >= 33) registerReceiver(receiver, IntentFilter(ReaderService.STATUS), RECEIVER_NOT_EXPORTED)
  else @Suppress("DEPRECATION") registerReceiver(receiver, IntentFilter(ReaderService.STATUS))
  prefs.getString("url", "")?.takeIf { it.startsWith("https://") }?.let { web.loadUrl(it) }
 }
 private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
 private fun saveState() { prefs.edit().putString("url", address.text.toString()).putString("text", content.text.toString()).putInt("speed", speed.progress).apply() }
 private fun openUrl() {
  var url = address.text.toString().trim()
  if (!url.startsWith("http")) url = "https://$url"
  if (!url.startsWith("https://")) { toast("Solo se admiten páginas HTTPS"); return }
  address.setText(url); web.visibility = View.VISIBLE; web.loadUrl(url); saveState()
 }
 private fun extract(thenTranslate: Boolean) {
  if (web.url == null) { toast("Abre una página primero"); return }
  val js = """(function(){let r=document.querySelector('article,main,[itemprop="articleBody"],.chapter-content,.chapter_content,.reading-content,.entry-content,.post-content,#chapter-content,#content')||document.body;let c=r.cloneNode(true);c.querySelectorAll('script,style,nav,footer,header,aside,button,form').forEach(e=>e.remove());let links=Array.from(document.querySelectorAll('a[href]'));let next=links.find(a=>/^(next|siguiente|próximo|下一章|次へ|다음)/i.test((a.innerText||'').trim())||/next/i.test(a.rel||''));return JSON.stringify({text:(c.innerText||c.textContent||'').trim(),title:document.title,next:next?next.href:''})})()"""
  web.evaluateJavascript(js) { raw ->
   try {
    val data = JSONObject(org.json.JSONArray("[$raw]").getString(0))
    original = data.optString("text"); translated = ""
    chapterTitle = data.optString("title"); nextUrl = data.optString("next")
    if (original.isBlank()) { toast("No se encontró texto legible"); return@evaluateJavascript }
    content.setText(original); status.text = "Extraídos ${original.length} caracteres"; saveState()
    if (thenTranslate) translate(true)
   } catch (e: Exception) { status.text = "Error al extraer: ${e.message}" }
  }
 }
 private fun openNext() {
  if (!nextUrl.startsWith("https://")) { toast("No se detectó el enlace del siguiente capítulo"); return }
  address.setText(nextUrl); openUrl()
 }
 private fun translate(playAfter: Boolean) {
  val sourceText = content.text.toString().trim()
  if (sourceText.isBlank()) { toast("No hay texto"); return }
  if (original.isBlank() || sourceText != translated) original = sourceText
  val codes = listOf("en", "zh-CN", "ja", "ko", "fr", "pt", "de", "es")
  val from = codes[languages.selectedItemPosition]
  if (from == "es") { translated = original; saveChapter(); if (playAfter) play(); return }
  val job = ++operation
  status.text = "Traduciendo…"
  thread {
   try {
    // Public MyMemory endpoint: quotas and long-chapter restrictions apply.
    val segments = original.chunked(420)
    if (segments.size > 80) throw IllegalArgumentException("El capítulo excede el límite del traductor gratuito (80 fragmentos).")
    val output = StringBuilder()
    segments.forEachIndexed { index, part ->
     if (job != operation) return@thread
     val endpoint = "https://api.mymemory.translated.net/get?q=${URLEncoder.encode(part, "UTF-8")}&langpair=${URLEncoder.encode("$from|es", "UTF-8")}" 
     val conn = URL(endpoint).openConnection() as HttpURLConnection
     conn.connectTimeout = 15000; conn.readTimeout = 20000
     try {
      val result = JSONObject(conn.inputStream.bufferedReader().use { it.readText() })
      if (result.optInt("responseStatus", 200) != 200) throw IllegalStateException(result.optString("responseDetails", "Límite del servicio"))
      output.append(android.text.Html.fromHtml(result.getJSONObject("responseData").getString("translatedText"), android.text.Html.FROM_HTML_MODE_LEGACY)).append('\n')
     } finally { conn.disconnect() }
     handler.post { if (job == operation) status.text = "Traduciendo ${index + 1}/${segments.size}" }
    }
    handler.post { if (job == operation) { translated = output.toString(); content.setText(translated); saveChapter(); status.text = "Traducción terminada y guardada"; if (playAfter) play() } }
   } catch (e: Exception) { handler.post { if (job == operation) status.text = "Error de traducción: ${e.message}" } }
  }
 }
 private fun saveChapter() {
  val url = address.text.toString().trim()
  if (!url.startsWith("https://")) { toast("Abre primero una URL HTTPS para guardar"); return }
  val current = content.text.toString()
  if (current.isBlank()) { toast("No hay texto que guardar"); return }
  library.save(url, chapterTitle.ifBlank { url }, original.ifBlank { current }, translated, nextUrl)
  saveState(); toast("Capítulo guardado para lectura sin conexión")
 }
 private fun showLibrary() {
  val chapters = library.all()
  if (chapters.isEmpty()) { toast("Todavía no hay capítulos guardados"); return }
  val titles = chapters.map { it.optString("title").take(80) }.toTypedArray()
  android.app.AlertDialog.Builder(this).setTitle("Biblioteca sin conexión").setItems(titles) { _, position ->
   val item = chapters[position]; address.setText(item.optString("url")); chapterTitle = item.optString("title")
   original = item.optString("original"); translated = item.optString("spanish"); nextUrl = item.optString("next")
   content.setText(translated.ifBlank { original }); web.visibility = View.GONE; status.text = "Capítulo cargado desde la biblioteca"; saveState()
  }.setNeutralButton("Borrar capítulo") { _, _ ->
   android.app.AlertDialog.Builder(this).setTitle("Eliminar de biblioteca").setItems(titles) { _, index -> library.delete(chapters[index].optString("url")); toast("Eliminado") }.show()
  }.setNegativeButton("Cerrar", null).show()
 }
 private fun play() {
  val text = content.text.toString().trim()
  if (text.isBlank()) { toast("No hay texto para escuchar"); return }
  val intent = Intent(this, ReaderService::class.java).setAction(ReaderService.ACTION_PLAY)
   .putExtra(ReaderService.EXTRA_TEXT, text).putExtra(ReaderService.EXTRA_RATE, .7f + speed.progress / 100f)
   .putExtra(ReaderService.EXTRA_NEXT_URL, nextUrl)
  startForegroundService(intent)
  status.text = "Iniciando narración…"
 }
 private fun player(action: String) { startService(Intent(this, ReaderService::class.java).setAction(action)) }
 override fun onPause() { super.onPause(); saveState() }
 override fun onDestroy() { operation++; unregisterReceiver(receiver); web.destroy(); super.onDestroy() }
}
