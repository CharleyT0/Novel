package com.novelavoz.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Private offline chapter cache; contains original and translated text. */
class LibraryStore(context: Context) {
 private val prefs = context.getSharedPreferences("novelavoz_library", Context.MODE_PRIVATE)
 fun save(url: String, title: String, original: String, spanish: String, nextUrl: String = "") {
  val array = all().filterNot { it.optString("url") == url }.toMutableList()
  array.add(0, JSONObject().put("url", url).put("title", title).put("original", original)
   .put("spanish", spanish).put("next", nextUrl).put("updated", System.currentTimeMillis()))
  val json = JSONArray(); array.take(200).forEach { json.put(it) }
  prefs.edit().putString("chapters", json.toString()).apply()
 }
 fun all(): List<JSONObject> = try {
  val json = JSONArray(prefs.getString("chapters", "[]"))
  (0 until json.length()).map { json.getJSONObject(it) }
 } catch (_: Exception) { emptyList() }
 fun get(url: String): JSONObject? = all().firstOrNull { it.optString("url") == url }
 fun delete(url: String) {
  val json = JSONArray(); all().filterNot { it.optString("url") == url }.forEach { json.put(it) }
  prefs.edit().putString("chapters", json.toString()).apply()
 }
}
