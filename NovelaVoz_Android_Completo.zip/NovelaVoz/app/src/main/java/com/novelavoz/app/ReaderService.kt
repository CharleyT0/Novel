package com.novelavoz.app

import android.app.*
import android.content.Intent
import android.os.*
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

/** Foreground TTS player: narration survives Activity backgrounding and screen lock. */
class ReaderService : Service(), TextToSpeech.OnInitListener {
 companion object {
  const val ACTION_PLAY = "com.novelavoz.PLAY"
  const val ACTION_PAUSE = "com.novelavoz.PAUSE"
  const val ACTION_STOP = "com.novelavoz.STOP"
  const val ACTION_NEXT = "com.novelavoz.NEXT"
  const val EXTRA_TEXT = "text"
  const val EXTRA_RATE = "rate"
  const val EXTRA_NEXT_URL = "next_url"
  const val CHANNEL = "novelavoz_reader"
  const val STATUS = "com.novelavoz.STATUS"
 }
 private lateinit var tts: TextToSpeech
 private val handler = Handler(Looper.getMainLooper())
 private var chunks: List<String> = emptyList()
 private var index = 0
 private var playing = false
 private var initialized = false
 private var rate = 1f
 private var nextUrl = ""
 private var session = 0
 override fun onCreate() {
  super.onCreate()
  val channel = NotificationChannel(CHANNEL, "Lectura de novelas", NotificationManager.IMPORTANCE_LOW)
  (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(channel)
  tts = TextToSpeech(this, this)
 }
 override fun onBind(intent: Intent?): IBinder? = null
 override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
  when (intent?.action) {
   ACTION_PLAY -> {
    val content = intent.getStringExtra(EXTRA_TEXT)
    if (content != null) {
     session++
     tts.stop()
     chunks = content.split(Regex("(?<=\\s)|(?<=[。！？.!?])")).fold(mutableListOf<String>()) { acc, piece ->
      if (acc.isEmpty() || acc.last().length + piece.length > 260) acc.add(piece.take(260))
      else acc[acc.lastIndex] += piece
      if (piece.length > 260) acc.addAll(piece.drop(260).chunked(260))
      acc
     }.filter { it.isNotBlank() }
     index = 0
     rate = intent.getFloatExtra(EXTRA_RATE, 1f).coerceIn(.5f, 2f)
     nextUrl = intent.getStringExtra(EXTRA_NEXT_URL).orEmpty()
    }
    playing = true
    startForeground(14, notification("Leyendo novela"))
    if (initialized) speak()
   }
   ACTION_PAUSE -> { playing = false; tts.stop(); index = (index - 1).coerceAtLeast(0); notifyState("Pausado") }
   ACTION_STOP -> { playing = false; session++; tts.stop(); stopForeground(STOP_FOREGROUND_REMOVE); stopSelf() }
   ACTION_NEXT -> { playing = false; tts.stop(); index = chunks.size; notifyState("Capítulo terminado") }
  }
  return START_NOT_STICKY
 }
 override fun onInit(status: Int) {
  initialized = status == TextToSpeech.SUCCESS && tts.setLanguage(Locale.forLanguageTag("es-ES")) >= TextToSpeech.LANG_AVAILABLE
  if (!initialized) { notifyState("Instala una voz española en Android"); return }
  tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
   override fun onStart(utteranceId: String?) {}
   override fun onError(utteranceId: String?) { notifyState("Error de voz") }
   override fun onDone(utteranceId: String?) {
    val finishedSession = utteranceId?.substringBefore('_')?.toIntOrNull()
    handler.post { if (playing && finishedSession == session) speak() }
   }
  })
  if (playing) speak()
 }
 private fun speak() {
  if (!playing || !initialized) return
  if (index >= chunks.size) {
   playing = false
   notifyState("Capítulo terminado", true)
   stopForeground(STOP_FOREGROUND_REMOVE)
   stopSelf()
   return
  }
  tts.setSpeechRate(rate)
  val part = chunks[index++]
  tts.speak(part, TextToSpeech.QUEUE_FLUSH, null, "${session}_${index}")
  notifyState("Leyendo fragmento $index de ${chunks.size}")
 }
 private fun notifyState(state: String, completed: Boolean = false) {
  sendBroadcast(Intent(STATUS).setPackage(packageName).putExtra("state", state).putExtra("completed", completed).putExtra("next_url", nextUrl))
  if (playing) (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).notify(14, notification(state))
 }
 private fun notification(state: String): Notification {
  val launch = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
  fun action(name: String, code: Int): PendingIntent = PendingIntent.getService(this, code, Intent(this, ReaderService::class.java).setAction(name), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
  return Notification.Builder(this, CHANNEL).setContentTitle("NovelaVoz").setContentText(state)
   .setSmallIcon(android.R.drawable.ic_media_play).setContentIntent(launch).setOngoing(playing)
   .addAction(Notification.Action.Builder(android.R.drawable.ic_media_pause, "Pausar", action(ACTION_PAUSE, 1)).build())
   .addAction(Notification.Action.Builder(android.R.drawable.ic_media_play, "Seguir", action(ACTION_PLAY, 2)).build())
   .addAction(Notification.Action.Builder(android.R.drawable.ic_menu_close_clear_cancel, "Detener", action(ACTION_STOP, 3)).build()).build()
 }
 override fun onDestroy() { if (::tts.isInitialized) { tts.stop(); tts.shutdown() }; super.onDestroy() }
}
